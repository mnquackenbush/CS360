package com.zybooks.eventtrackingapp.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

// One event in the Events table, belonging to a single user
@Entity(tableName = "events", indices = {@Index(value = "userId")})
public class Event {
    @PrimaryKey(autoGenerate = true)
    private long id;
    private long userId;
    @NonNull
    private String name;

    // Time of event in Epoch Time
    private long eventTimeMillis;

    // Flags whether not an SMS reminder
    // has been sent for an event.
    private boolean reminderSent;

    public Event(long userId, @NonNull String name, long eventTimeMillis) {
        this.userId = userId;
        this.name = name;
        this.eventTimeMillis = eventTimeMillis;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public long getEventTimeMillis() {
        return eventTimeMillis;
    }

    public void setEventTimeMillis(long eventTimeMillis) {
        this.eventTimeMillis = eventTimeMillis;
    }

    public boolean isReminderSent() {
        return reminderSent;
    }

    public void setReminderSent(boolean reminderSent) {
        this.reminderSent = reminderSent;
    }
}
