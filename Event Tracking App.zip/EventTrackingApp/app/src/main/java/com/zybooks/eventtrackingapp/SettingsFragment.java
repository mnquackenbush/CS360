package com.zybooks.eventtrackingapp;

import android.Manifest;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.snackbar.Snackbar;
import com.zybooks.eventtrackingapp.notifications.SmsNotifier;

// Settings screen: Turns SMS reminders on or off, asking Android for SMS permission when needed
public class SettingsFragment extends Fragment {

    private MaterialSwitch smsSwitch;
    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    SmsNotifier.setEnabled(requireContext(), true);
                    smsSwitch.setChecked(true);
                } else {
                    Snackbar.make(requireView(), R.string.sms_denied_snackbar, Snackbar.LENGTH_LONG).show();
                }
            });

    @Override
    public void onResume() {
        super.onResume();
        smsSwitch.setChecked(SmsNotifier.remindersActive(requireContext()));
    }

    public SettingsFragment() {
        super(R.layout.fragment_settings);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        smsSwitch = view.findViewById(R.id.smsSwitch);
        smsSwitch.setOnClickListener(v -> {
            if (!smsSwitch.isChecked()) {
                SmsNotifier.setEnabled(requireContext(), false);
                return;
            }
            if (SmsNotifier.hasPermission(requireContext())) {
                SmsNotifier.setEnabled(requireContext(), true);
            } else {
                smsSwitch.setChecked(false);
                showOptInDialog();
            }
        });
        toolbar.setNavigationOnClickListener(v -> {
            Navigation.findNavController(v).navigateUp();
        });
    }

    private void showOptInDialog() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.sms_opt_in_title)
                .setMessage(R.string.sms_opt_in_message)
                .setPositiveButton(R.string.sms_opt_in_continue, (dialog, which) ->
                        permissionLauncher.launch(Manifest.permission.SEND_SMS))
                .setNegativeButton(R.string.sms_opt_in_not_now, null)
                .show();
    }
}