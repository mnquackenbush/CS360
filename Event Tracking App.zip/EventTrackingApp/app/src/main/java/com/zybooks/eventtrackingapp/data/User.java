package com.zybooks.eventtrackingapp.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

// One registered account in the Users table
@Entity(tableName = "users", indices = {@Index(value = "username", unique = true)})
public class User {

    @PrimaryKey(autoGenerate = true)
    private long id;
    @NonNull
    private String username;

    // Plaintext password for the assignment
    // If this app was being uploaded to the Play store
    // encryption would be necessary for security.
    @NonNull
    private String password;

    // Constructor Method for User entity
    public User(@NonNull String username, @NonNull String password) {
        this.username = username;
        this.password = password;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @NonNull
    public String getUsername() {
        return username;
    }

    public void setUsername(@NonNull String username) {
        this.username = username;
    }

    @NonNull
    public String getPassword() {
        return password;
    }

    public void setPassword(@NonNull String password) {
        this.password = password;
    }
}
