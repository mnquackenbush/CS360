package com.zybooks.eventtrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.zybooks.eventtrackingapp.data.AppDatabase;
import com.zybooks.eventtrackingapp.data.User;
import com.zybooks.eventtrackingapp.data.UserDao;

import java.util.concurrent.Executor;

// Login screen: Checks credentials against the database and creates new accounts
public class LoginFragment extends Fragment {

    private EditText usernameInput;
    private EditText passwordInput;
    public LoginFragment() {
        super(R.layout.fragment_login);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        usernameInput = view.findViewById(R.id.usernameInput);
        passwordInput = view.findViewById(R.id.passwordInput);

        view.findViewById(R.id.loginButton).setOnClickListener(v -> {
            if (!validateInput()) return;
            logIn();
        });

        view.findViewById(R.id.createAccountButton).setOnClickListener(v -> {
            if (!validateInput()) return;
            createAccount();
        });
    }

    // Helper function to ensure that both username and password
    // fields are filled out in the Login form.
    private boolean validateInput() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (username.isEmpty()) {
            usernameInput.setError(getString(R.string.error_username_required));
            usernameInput.requestFocus();
            return false;
        }

        if (password.isEmpty()) {
            passwordInput.setError(getString(R.string.error_password_required));
            passwordInput.requestFocus();
            return false;
        }

        return true;
    }

    // Registers a new account if the username is free,
    // then logs the user in.
    private void createAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        UserDao userDao = AppDatabase.getInstance(requireContext()).userDao();
        Executor mainThread = ContextCompat.getMainExecutor(requireContext());

        AppDatabase.databaseExecutor.execute(() -> {
            if (userDao.findByUsername(username) != null) {
                mainThread.execute(() -> {
                    if (!isAdded()) return;
                    usernameInput.setError(getString(R.string.error_username_taken));
                    usernameInput.requestFocus();
                });
                return;
            }
            long newUserId = userDao.insert(new User(username, password));
            mainThread.execute(() -> {
                if (!isAdded()) return;
                goToEvents(newUserId);
            });
        });
    }

    // Logs in an existing user if the username and password match
    private void logIn() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        UserDao userDao = AppDatabase.getInstance(requireContext()).userDao();
        Executor mainThread = ContextCompat.getMainExecutor(requireContext());

        AppDatabase.databaseExecutor.execute(() -> {
            User user = userDao.findByUsername(username);
            mainThread.execute(() -> {
                if (!isAdded()) return;
                if (user == null) {
                    usernameInput.setError(getString(R.string.error_username_nonexistent));
                }
                else if (!user.getPassword().equals(password)) {
                    passwordInput.setError(getString(R.string.error_password_incorrect));
                }
                else {
                    goToEvents(user.getId());
                }
            });
        });
    }

    // Opens the Events screen for the specified user
    private void goToEvents(long userId) {
        Bundle args = new Bundle();
        args.putLong(EventsFragment.ARG_USER_ID, userId);
        Navigation.findNavController(requireView()).navigate(R.id.action_login_to_events, args);
    }
}
