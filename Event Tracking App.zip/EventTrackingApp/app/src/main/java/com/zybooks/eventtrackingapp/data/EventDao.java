package com.zybooks.eventtrackingapp.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// Database CRUD operations and operations for finding events due to a reminder
@Dao
public interface EventDao {
    @Insert
    long insert(Event event);

    @Update
    void update(Event event);

    @Delete
    void delete(Event event);

    @Query("SELECT * FROM events WHERE userId = :userId ORDER BY eventTimeMillis ASC")
    LiveData<List<Event>> getEventsForUser(long userId);

    // Returns a specified user's events that haven't yet received an SMS reminder.
    @Query("SELECT * FROM events WHERE userId = :userId AND reminderSent = 0 AND eventTimeMillis BETWEEN :fromMillis AND :toMillis")
    List<Event> findEventsNeedingReminder(long userId, long fromMillis, long toMillis);
}
