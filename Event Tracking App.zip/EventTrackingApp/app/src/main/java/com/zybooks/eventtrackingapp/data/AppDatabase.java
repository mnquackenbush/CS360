package com.zybooks.eventtrackingapp.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Central database for the application storing the users
// with their corresponding events
@Database(entities = {User.class, Event.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    // All write and one-time queries execute here in order
    // as Room implementation forbids database work on the main thread.
    public static final ExecutorService databaseExecutor = Executors.newSingleThreadExecutor();
    public abstract UserDao userDao();
    public abstract EventDao eventDao();

    // Returns the app's singleton shared database
    // (Creates the database on the first use.)
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, "event_tracker.db").build();
        }
        return instance;
    }
}
