package com.zybooks.eventtrackingapp;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.zybooks.eventtrackingapp.data.AppDatabase;
import com.zybooks.eventtrackingapp.data.Event;
import com.zybooks.eventtrackingapp.data.EventDao;
import com.zybooks.eventtrackingapp.notifications.SmsNotifier;

// Main screen: Shows the user's events in a grid, handles adding, editing, and deleting them,
// and sends SMS reminders that are due.
public class EventsFragment extends Fragment implements EventAdapter.OnEventActionListener {

    public EventsFragment() {
        super(R.layout.fragment_events);
    }
    public static final String ARG_USER_ID = "userId";
    private long userId;
    private EventDao eventDao;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        userId = requireArguments().getLong(ARG_USER_ID);
        RecyclerView recyclerView = view.findViewById(R.id.eventsGrid);
        EventAdapter eventAdapter = new EventAdapter(this);
        recyclerView.setAdapter(eventAdapter);
        eventDao = AppDatabase.getInstance(requireContext()).eventDao();
        TextView emptyStateText = view.findViewById(R.id.emptyState);
        eventDao.getEventsForUser(userId).observe(getViewLifecycleOwner(), events -> {
            eventAdapter.submitList(events);
            if (events.isEmpty()) {
                emptyStateText.setVisibility(View.VISIBLE);
            }
            else {
                emptyStateText.setVisibility(View.GONE);
            }
        });

        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_log_out) {
                Navigation.findNavController(view).navigate(R.id.action_events_to_login);
                return true;
            }
            if (item.getItemId() == R.id.action_settings) {
                Navigation.findNavController(view).navigate(R.id.action_events_to_settings);
                return true;
            }
            return false;
        });

        view.findViewById(R.id.addEventButton).setOnClickListener(v -> {
            EventDialog.show(requireContext(), null, (name, eventTimeMillis) -> {
                AppDatabase.databaseExecutor.execute(() -> {
                    eventDao.insert(new Event(userId, name, eventTimeMillis));
                });
            });
        });

        sendDueReminders();
    }

    private void confirmDelete(Event event) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.delete_event_title)
                .setMessage(getString(R.string.delete_event_message, event.getName()))
                .setPositiveButton(R.string.delete, ((dialog, which) ->
                        AppDatabase.databaseExecutor.execute(() -> eventDao.delete(event))))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    public void onDelete(Event event) {
        confirmDelete(event);
    }

    @Override
    public void onEdit(Event event) {
        EventDialog.show(requireContext(), event, (name, eventTimeMillis) -> {
            // Builds a copy of the existing event into the "Edit Event" dialog,
            // rather than starting blank.
            Event updatedEvent = new Event(userId, name, eventTimeMillis);
            updatedEvent.setId(event.getId());
            if (updatedEvent.getEventTimeMillis() == event.getEventTimeMillis()) {
                updatedEvent.setReminderSent(event.isReminderSent());
            }
            AppDatabase.databaseExecutor.execute(() -> {
                eventDao.update(updatedEvent);
            });
        });
    }

    // Texts a reminder for each of the user's events starting within the reminder window
    private void sendDueReminders() {
        Context appContext = requireContext().getApplicationContext();
        if (!SmsNotifier.remindersActive(appContext)) {
            return;
        }
        long now = System.currentTimeMillis();
        long windowEnd = System.currentTimeMillis() + SmsNotifier.REMINDER_WINDOW_MILLIS;
        AppDatabase.databaseExecutor.execute(() -> {
            for (Event event : eventDao.findEventsNeedingReminder(userId, now, windowEnd)) {
                SmsNotifier.sendReminder(appContext, event);
                event.setReminderSent(true);
                eventDao.update(event);
            }
        });
    }
}
