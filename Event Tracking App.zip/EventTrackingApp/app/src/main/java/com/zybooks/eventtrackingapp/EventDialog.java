package com.zybooks.eventtrackingapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;
import com.zybooks.eventtrackingapp.data.Event;

import java.text.DateFormat;
import java.util.Calendar;

// Shows the add / update event dialog and reports what the user input
public class EventDialog {

    // Receives the user's input when they click Save.
    public interface OnSaveListener {
        void onSave(String name, long eventTimeMillis);
    }

    // Shows the dialog. Pass an existing event to edit it, or null to add a new one.
    public static void show(Context context, @Nullable Event existing, OnSaveListener listener) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_event, null);
        Calendar chosen = Calendar.getInstance();
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        DateFormat timeFormat = DateFormat.getTimeInstance(DateFormat.SHORT);
        EditText nameInput = dialogView.findViewById(R.id.eventNameInput);
        EditText dateInput = dialogView.findViewById(R.id.eventDateInput);
        EditText timeInput = dialogView.findViewById(R.id.eventTimeInput);
        TextInputLayout nameLayout = dialogView.findViewById(R.id.eventNameLayout);
        TextInputLayout dateLayout = dialogView.findViewById(R.id.eventDateLayout);
        TextInputLayout timeLayout = dialogView.findViewById(R.id.eventTimeLayout);

        dateInput.setOnClickListener(v -> new DatePickerDialog(
                context,
                (picker, year, month, dayOfMonth) -> {
                    chosen.set(year, month, dayOfMonth);
                    dateInput.setText(dateFormat.format(chosen.getTime()));
                },
                chosen.get(Calendar.YEAR),
                chosen.get(Calendar.MONTH),
                chosen.get(Calendar.DAY_OF_MONTH)
        ).show());

        timeInput.setOnClickListener(v -> new TimePickerDialog(
                context,
                (picker, hourOfDay, minute) -> {
                    chosen.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    chosen.set(Calendar.MINUTE, minute);
                    timeInput.setText(timeFormat.format(chosen.getTime()));
                },
                chosen.get(Calendar.HOUR_OF_DAY),
                chosen.get(Calendar.MINUTE),
                android.text.format.DateFormat.is24HourFormat(context)
        ).show());

        if (existing != null) {
            nameInput.setText(existing.getName());
            chosen.setTimeInMillis(existing.getEventTimeMillis());
            dateInput.setText(dateFormat.format(chosen.getTime()));
            timeInput.setText(timeFormat.format(chosen.getTime()));
        }

        AlertDialog dialog = new MaterialAlertDialogBuilder(context)
                .setTitle(existing == null ? R.string.add_event : R.string.edit_event)
                .setView(dialogView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            nameLayout.setError(null);
            dateLayout.setError(null);
            timeLayout.setError(null);
            boolean valid = true;
            if (nameInput.getText().toString().trim().isEmpty()) {
                nameLayout.setError(context.getString(R.string.empty_event_name_error));
                valid = false;
            }
            if (dateInput.getText().toString().trim().isEmpty()) {
                dateLayout.setError(context.getString(R.string.empty_event_date_error));
                valid = false;
            }
            if (timeInput.getText().toString().trim().isEmpty()) {
                timeLayout.setError(context.getString(R.string.empty_event_time_error));
                valid = false;
            }
            if (!valid) return;
            listener.onSave(nameInput.getText().toString().trim(), chosen.getTimeInMillis());
            dialog.dismiss();
        });
    }
}
