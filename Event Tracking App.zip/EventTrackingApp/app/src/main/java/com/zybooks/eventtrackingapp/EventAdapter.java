package com.zybooks.eventtrackingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.eventtrackingapp.data.Event;

import java.text.DateFormat;
import java.util.Date;

// Fills the events grid's rows and reports taps on them to its listener
public class EventAdapter extends ListAdapter<Event, EventAdapter.EventViewHolder> {

    // Fields to format the Epoch time into meaningful Human-readable format
    private final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
    private final DateFormat timeFormat = DateFormat.getTimeInstance(DateFormat.SHORT);

    // Field to hold the Event Action Listener
    private final OnEventActionListener listener;

    // Tells ListAdapter how to compare events when the list changes
    private static final DiffUtil.ItemCallback<Event> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<Event>() {
                @Override
                public boolean areItemsTheSame(@NonNull Event oldItem, @NonNull Event newItem) {
                    return oldItem.getId() == newItem.getId();
                }

                @Override
                public boolean areContentsTheSame(@NonNull Event oldItem, @NonNull Event newItem) {
                    return oldItem.getName().equals(newItem.getName())
                            && oldItem.getEventTimeMillis() == newItem.getEventTimeMillis()
                            && oldItem.isReminderSent() == newItem.isReminderSent();
                }
            };

    // Receives taps on a row's controls, so that the adapter itself never
    // directly touches the database.
    public interface OnEventActionListener {
        void onDelete(Event event);
        void onEdit(Event event);
    }

    public EventAdapter(OnEventActionListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = getItem(position);
        holder.eventNameText.setText(event.getName());
        holder.eventDateText.setText(dateFormat.format(new Date(event.getEventTimeMillis())));
        holder.eventTimeText.setText(timeFormat.format(new Date(event.getEventTimeMillis())));
        holder.deleteButton.setOnClickListener(v -> listener.onDelete(event));
        holder.rowContent.setOnClickListener(v -> listener.onEdit(event));

        Context context = holder.itemView.getContext();
        String description = context.getString(R.string.delete_event_description, event.getName());
        holder.deleteButton.setContentDescription(description);
    }

    // Holds the views for a single row of the events grid
    static class EventViewHolder extends RecyclerView.ViewHolder {
        private final TextView eventNameText;
        private final TextView eventDateText;
        private final TextView eventTimeText;
        private final ImageButton deleteButton;
        private final View rowContent;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventNameText = itemView.findViewById(R.id.eventName);
            eventDateText = itemView.findViewById(R.id.eventDate);
            eventTimeText = itemView.findViewById(R.id.eventTime);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            rowContent = itemView.findViewById(R.id.rowContent);
        }
    }
}
