package com.zybooks.eventtrackingapp.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// Database operations for user accounts
@Dao
public interface UserDao {
    @Insert
    long insert(User user);

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User findByUsername(String username);
}
