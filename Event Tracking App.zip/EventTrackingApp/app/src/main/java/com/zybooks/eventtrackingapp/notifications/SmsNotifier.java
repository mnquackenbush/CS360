package com.zybooks.eventtrackingapp.notifications;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import com.zybooks.eventtrackingapp.R;
import com.zybooks.eventtrackingapp.data.Event;

import java.text.DateFormat;
import java.util.Date;

// Checks SMS permission and preferences and sends event reminders.
public class SmsNotifier {

    // The emulator's phone number; Sends texts to the emulator's messages app.
    private static final String DESTINATION_NUMBER = "5554";

    // How far ahead to look for events that need a reminder: 24 Hours
    public static final long REMINDER_WINDOW_MILLIS = 24L * 60 * 60 * 1000;

    private static final String PREFS_NAME = "sms_settings";
    private static final String KEY_REMINDERS_ON = "reminders_on";

    // Returns true if Android has permission from the app to send SMS
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Returns true if the user has turned reminders on in Settings
    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_REMINDERS_ON, false);
    }

    // Saves whether the user wants reminders
    public static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_REMINDERS_ON, enabled).apply();
    }

    // Returns true only if Android allows SMS and the user has turned reminders on.
    public static boolean remindersActive(Context context) {
        return hasPermission(context) && isEnabled(context);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static void sendReminder(Context context, Event event) {
        if (!hasPermission(context)) {
            return;
        }
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        DateFormat timeFormat = DateFormat.getTimeInstance(DateFormat.SHORT);
        Date eventDate = new Date(event.getEventTimeMillis());
        String message = context.getString(
                R.string.sms_reminder_message,
                event.getName(),
                dateFormat.format(eventDate),
                timeFormat.format(eventDate)
        );
        SmsManager smsManager;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            smsManager = context.getSystemService(SmsManager.class);
        } else {
            smsManager = SmsManager.getDefault();
        }
        smsManager.sendTextMessage(DESTINATION_NUMBER, null, message, null, null);
    }
}
